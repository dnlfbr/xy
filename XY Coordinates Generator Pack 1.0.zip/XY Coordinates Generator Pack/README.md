// xy coordinates generators pack

A collection of tools to generate XY coordinates in gen~.  Exploring different methods to interact with movements, trajectories and location in a two dimensional space.
 

installation

--> move the ‘XY Coordinates Generators Pack’ folder to Documents/Max8/Packages


contents

- helps


- codes


- snippets


- clippings


- examples



notes

- all outlets ranging signal from 0 to 1
- gen~ codes are optimised to work in multichannel 



thanks for the support, collaboration and inspiration to:
MUSIC INFORMATICS: Umanesimo Artificiale, Tauro Venturini, Filippo Rosati, Francesco Corvi, Emanuele Balia, Artiom Costantinov, Sasha Petra
/ GRAIM: Nicola Di Paolo, Franco Conte, Davide Tiso, Lorenzo Pagliei, Carmine Emanuele Cella
 / STEIM: Fedde ten Berge



--- Daniele Fabris LEDEN / @musicinformatics 202105 ---

